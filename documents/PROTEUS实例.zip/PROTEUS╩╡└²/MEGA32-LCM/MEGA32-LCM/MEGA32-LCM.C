//ICC-AVR application builder : 2006-5-9 12:31:05
// Target : M32
// Crystal: 16.000Mhz
// FILES  : MEGA32-LCM.C

#include <iom32v.h>
#include <macros.h>

/*************LCD��������**************/

volatile

#define	 
#define LCD_EH   bit(PORTB.2)
unsigned char lcd_row_addr,lcd_