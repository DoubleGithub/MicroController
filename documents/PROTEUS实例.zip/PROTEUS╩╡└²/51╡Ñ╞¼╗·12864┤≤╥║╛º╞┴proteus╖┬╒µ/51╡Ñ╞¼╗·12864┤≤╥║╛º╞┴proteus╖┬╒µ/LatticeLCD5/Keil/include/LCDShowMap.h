#ifndef __LCDSHOWMAP_H__
#define __LCDSHOWMAP_H__

extern unsigned char code uca_QING[];/*"��",0*/

extern unsigned char code uca_SHU[];/*"��",1*/

extern unsigned char code uca_RU[];/*"��",2*/

extern unsigned char code uca_MAOHAO[];/*"��",3*/

extern unsigned char code uca_BLANK[];


extern unsigned char code uca_0[];//*"0",0*

extern unsigned char code uca_1[];//*"1",1*

extern unsigned char code uca_2[];//*"2",2*

extern unsigned char code uca_3[];//*"3",3*

extern unsigned char code uca_4[];//*"4",4*

extern unsigned char code uca_5[];//*"5",5*

extern unsigned char code uca_6[];//*"6",6*

extern unsigned char code uca_7[];//*"7",7*

extern unsigned char code uca_8[];//*"8",8*

extern unsigned char code uca_9[];//*"9",9*

extern unsigned char code uca_JIA[];//*"+",10

extern unsigned char code uca_JIAN[];//*"-",11

extern unsigned char code uca_CHENG[];//*"*",12

extern unsigned char code uca_CHU[];//*"/",13

extern unsigned char code uca_DENG[];//*"=",14

extern unsigned char code uca_Pig[];


#endif