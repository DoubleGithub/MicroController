#define PA8255     XBYTE[0x8000]
#define PB8255     XBYTE[0x8001]
#define PC8255     XBYTE[0x8002]
#define COM8255    XBYTE[0x8003]