#ifndef __INPUTCHAR_H__
#define __INPUTCHAR_H__

unsigned char ucGetLetter(unsigned char ucKeyCode);

#endif