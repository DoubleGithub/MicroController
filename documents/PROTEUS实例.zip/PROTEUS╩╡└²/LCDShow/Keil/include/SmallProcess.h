#ifndef __SMALLPROCESS_H__
#define __SMALLPROCESS_H__

unsigned char ucSmallOne(unsigned char ucKeyCode);

unsigned char ucSmallTwo(unsigned char ucKeyCode);

unsigned char ucSmallThree(unsigned char ucKeyCode);

#endif