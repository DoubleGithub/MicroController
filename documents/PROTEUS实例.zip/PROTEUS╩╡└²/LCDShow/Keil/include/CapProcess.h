#ifndef __CAPPROCESS_H__
#define __CAPPROCESS_H__

unsigned char ucCapOne(unsigned char ucKeyCode);

unsigned char ucCapTwo(unsigned char ucKeyCode);

unsigned char ucCapThree(unsigned char ucKeyCode);

#endif