#ifndef __INPUTNUMBER_H__
#define __INPUTNUMBER_H__

unsigned char ucGetNum(unsigned char ucKeyCode);

#endif