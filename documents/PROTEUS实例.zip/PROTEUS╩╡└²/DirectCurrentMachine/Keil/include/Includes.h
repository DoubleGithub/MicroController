#ifndef __INCLUDES_H__
#define __INCLUDES_H__

#include <at89x51.h>

#include "KeyScan.h"

#include "SMC1602.h"

#include "KeyProcess.h"

#endif