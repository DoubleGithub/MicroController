#ifndef __delay_h__
#define __delay_h__

/***************************************/

void delay(unsigned int n)
{
 	unsigned int i;
	for(;n>0;n--)
	{
	 		for(i=50;i>0;i--)
			{
				;
			}
	}
}

/**************************************/

#endif
